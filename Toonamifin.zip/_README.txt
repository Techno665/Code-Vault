This will make Toonami Aftermath work in Jellyfin (Including the EPG)
First you'll need to download the following
https://git-scm.com/downloads
https://nodejs.org/en/download
https://github.com/skeeto/w64devkit/releases

NOTE: For Git & Node.js, the Standalone Binary (Zip) are fine, you just have to make sure that you add them to your Environment Path
run _Install.bat
Then run the batch files in order from 1 to 3

1.bat & 3.bat have things that need to be manually changed to make them work, these will be noted with "@REM IMPORTANT:"

Automate:
If you would like to have this automated, you can use Task Scheduler to run the batch files for you.
Search Task Scheduler and Open it
Click "Task Scheduler Library" on the left then "Create Task" on the right
Name it what ever you like then go to "Triggers" and new
Set it for however often you want (I have mine set for once a week on Monday)
Next go action and new, choose "Start a program" and point it to 1.bat (Repeat this for 2.bat & 3.bat)
Lastly go to Settings and enable "Run task as soon as possible if missed"

Setting up Toonami:
in Jellyfin go to Dashboard and LiveTV
Click the + next to "Tuner Devices" and select "M3U Tuner"
Past the following link
https://raw.githubusercontent.com/kbmystery7/TAM3U8/main/TAM3U8.m3u8
Go down and click "Auto-loop live streams"
Save
Click the + next to "TV Guide Data Providers" and select XMLTV
Point it to "East.xml" and save (Repeat this for Pacific.xml)
Jellyfin should now have an EPG for Toonami
NOTE: It may not have entires for shows that are playing when you first run it as they may have already been removed from the Toonami Aftermath website's EPG


Current Problems:
1. I'm unsure how to remove entries that have already been passed without using a more powerful coding language like Python
2. Jellyfin doesn't seem to support gifs for Live TV so you won't get any images for shows since Toonami Aftermath uses gifs